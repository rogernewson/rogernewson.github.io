.h parmhet
