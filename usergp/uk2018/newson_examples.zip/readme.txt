Example do-files

These do-files were used in making the presentation:

A fleet of packages for inputting United Kingdom primary care data

presented at the 2018 London Stata Conference, 06–07 September, 2018. The
do-files are as follows:

Do-file          Description
-------          -----------
create.do        Master do-file calling 3 servant do-files
lookups.do       Servant do-file creating lookup datasets and lookup do-file
practice.do      Servant do-file creating practice dataset
patient.do       Servant do-file creating patient dataset
patientstats1.do Do-file inputting patient dataset and outputting patient
                 statistics

The file create1.do creates a CPRD dataset, assuming that there is a folder
"../../../../cprddata", containing a CPRD text data retrieval, and a subfolder
"./dta", in which the CPRD Stata dataset is to be created. It does this by
calling the servant do-files lookups.do, practice.do and patient.do to create
the lookups dataset and do-file, the practice dataset, and the patient dataset,
respectively, using the SSC package dolog. The file patientstats1.do should
probably be called using dolog. It inputs the patient dataset and outputs
patient statistics.

Roger Newson
08 September 2018
