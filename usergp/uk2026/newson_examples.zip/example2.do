#delim ;
version 17.0;

*
 Example for the 2026 Stata Conference with a .pdf file.
 SSC packages required:
 bmjcip chardef eclplot listtab regaxis scheme_rbn1mono sdecode tfinsert xauto xcontract xsvmat
*;

clear all;
set scheme rbn4mono;

* Input data *;
xauto, clear;
xcontract firm, list(, abbr(32));

* Estimate percentiles *;
rcentile tons, cluster(firm) centile(0(25)100);
retu list;
local Nfirm=r(N_clust);
local Nmodel=r(N);
xsvmat, from(r(cimat)) fast names(col) format(Centile Minimum Maximum %8.3f)
  list(, abbr(32));

* Beginning of document creation section *;
tempname rmdhandle;
file open `rmdhandle' using example2.Rmd,
  write text replace;
capture noisily {;

* Add YAML metadata *;
#delim cr
tfinsert `rmdhandle', terminator(END_OF_YAML) maxlines(999999)
---
title:  Percentiles of weight in tons in the `xauto` data
author: Roger B. Newson
output: pdf_document
---
END_OF_YAML
#delim ;

* Add preamble *;
#delim cr
tfinsert `rmdhandle', terminator(END_OF_RMD) maxlines(999999)

Methods
-------

We used the Mata-based SSC package `rcentile` to estimate percentiles
0 to 100 by 25, with confidence intervals clustered by the variable `firm`,
meaning that we are sampling firms from a population of firms,
instead of models from a population of models. A 100$\alpha$th percentile
of a variable $Y$ is defined informally as a solution in $\theta$ of the equation
$$
C_Y(\theta)=\alpha,
$$
where $C_Y(\cdot)$ is the centre ridit function of $Y$.

Results
-------

The percentiles are plotted in Figure 1 and tabulated in Table 1.

END_OF_RMD

#delim ;

* Add Figure *;
file write `rmdhandle' _n "\newpage"
  _n _n
  "## Figure 1. Percentiles of weight in tons in the `xauto` data "
  "(`Nfirm' firms, `Nmodel' models)"
  _n _n;
regaxis Centile Minimum Maximum, ltick(xlabs) inc(0);
eclplot Centile Minimum Maximum Percent, hori eplot(connected) rplot(rcap)
  estopts(sort)
  ylab(0(25)100)
  xlab(`xlabs', format(%-8.1f))
  xtitle("Percentile (tons) with 95% CI")
  xsize(8) ysize(6);
graph export figure1.pdf, replace;
file write `rmdhandle' _n "![](figure1.pdf)";

* Add Table *;
file write `rmdhandle'
  _n _n
  "## Table 1. Percentiles of weight in tons in the `xauto` data "
  "(`Nfirm' firms, `Nmodel' models)"
  _n _n;
preserve;
bmjcip Centile Minimum Maximum;
sdecode Percent, replace;
chardef Percent Centile Minimum Maximum,
 char(varname) val(Percent Percentile "(95%" "CI)") pref(*) suff(*);
chardef Percent Centile Minimum Maximum,
  char(halign) val(---:);
listtab Percent Centile Minimum Maximum, handle("`rmdhandle'")
  rstyle(markdown) headc(varname halign);
restore;  

};
file close `rmdhandle';
* End of document creation section *;





  

exit;
