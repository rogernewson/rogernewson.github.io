Files in this folder

These files are the do-files, the .Rmd primary output files,
the .docx template file for the .docx output file referenced
by the corresponding .Rmd file, and the .html, .pdf, and
.docx output files produced by RStudio from the .Rmd files.
The files are as follows:

File                    Description
----                    -----------
readme.txt              This file
example1.do             do-file for the .html example
example2.do             do-file for the .pdf example
example3.do             do-file for the .docx example
example1.Rmd            .Rmd file for the .html example
example2.Rmd            .Rmd file for the .pdf example
example3.Rmd            .Rmd file for the .docx example
example3_template.docx  Template for the .docx example
example1.html           Output document for the .html example
example2.pdf            Output document for the .pdf example
example3.docx           Output document for the .docx example

For each example xyz, the file xyz.do creates the file xyz.Rmd,
which is input by RStudio to create the final output document
xyz, with a file extension appropriate to its document format.

Roger Newson
10 June 2026

