
<h1>Regression of fuel consumption with respect to car weight in the <tt>xauto</tt> data</h1>

In the dataset uploaded using the SSC package `xauto`,
we fitted a linear regression model
of fuel consumption (in nipperkins per mile)
with respect to car weight (in US tons),
separately for the 2 car model origin groups
(non-US models and US models).
In each regression model, the regression slope was a weight effect on fuel consumption
(expressed in nipperkins per additional ton-mile),
and the intercept was a mean fuel consumption
(expressed in nipperkins per mile)
for a fantasy car with zero weight.

<h2>Table 1. Regression of fuel consumption with respect to weight (long version using <tt>insingap</tt>)</h2>

|*Parameter*|*Estimate*|*(95%*|*CI)*|*P*|
|:---|---:|---:|---:|:---|
|**Non-US (N=22):**|||||
|Weight (US tons)|11.059|(8.130,|13.987)|1.5x10<sup>-7</sup>|
|Constant|-1.764|(-5.382,|1.853)|.32|
|**US (N=52):**|||||
|Weight (US tons)|7.885|(6.484,|9.286)|2.2x10<sup>-15</sup>|
|Constant|0.537|(-1.549,|2.622)|.61|

<h2>Table 2. Regression of fuel consumption with respect to weight (wide version using <tt>xrewide</tt>)</h2>

| |*Non-US (N=22):*| | | |*US (N=52):*| | | |
|*Parameter*|*Estimate*|*(95%*|*CI)*|*P*|*Estimate*|*(95%*|*CI)*|*P*|
|:---|---:|---:|---:|:---|---:|---:|---:|:---|
|Weight (US tons)|11.059|(8.130,|13.987)|1.5x10<sup>-7</sup>|7.885|(6.484,|9.286)|2.2x10<sup>-15</sup>|
|Constant|-1.764|(-5.382,|1.853)|.32|0.537|(-1.549,|2.622)|.61|
