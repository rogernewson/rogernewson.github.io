Files in this folder
--------------------

The files are as follows:

File            Description
----            -----------
readme.txt      This file
create1.do      Master do file (calling the others)
result1.do      Create resultsset in result1.dta
mymddoc1.do     Create Markdown and HTML documents
mydocxdoc1.do   Create .docx document
mymddoc1.md     Markdown document created by mymddoc1.do
mymddoc1.htm    HTML document created by mymddoc1.do
mydocxdoc1.docx .docx document created by mydocxdoc1.do

The example do-files are run after unzipping these files in a
folder, starting Stata in that folder, and typing, in Stata,

do create1

The SSC documents required by each do file are listed at the
top of that do file.

Roger Newson
24 January 2023
