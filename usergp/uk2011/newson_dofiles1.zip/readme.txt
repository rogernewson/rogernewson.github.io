The do-files in this folder
---------------------------

These were used to create the examples and graphs in the
presentation

Sensible parameters for polynomials and other splines

presented at the UK Stata User Meeting in 2011. Each do-file
inputs one or more Stata dataset files and outputs one or more
Stata datasets and/or Encapsulated PostScript (.eps) graphics
files.

The files, together with the input files required and the
output files created, are as follows:

Do-file         Input files     Output files
-------         -----------     ------------
dscreate1.do    auto.dta        spparam1.dta
                                spxvar1.dta
figures1.do     auto.dta        figseq1.eps
                spparam1.dta    figseq2.eps
                spxvar1.dta
figures2.do     spxvar1.dta     figseq3.eps
                                figseq4.eps
                                figseq5.eps
                                figseq6.eps
example1.do     auto.dta        figseq7.eps
                                figseq8.eps

The files figseq1.eps to figseq8.eps will contain the graphs in
the presentation, numbered in order of appearance. The dataset
auto.dta is distributed with official Stata, and has 1
observation for each of 74 car models, and can be input by
typing, in Stata,

sysuse auto, clear

The dataset spparam1.dta has 1 observation for each of the 6
parameters of each of the 4 splines displayed in the first 2
graphs of the presentation, and data on parameter names,
estimates, confidence limits, and other parameter attributes.
The dataset spxvar1.do has 1 observation for each combination
of the 4 spline degrees (0, 1, 2 and 3) and the 3081 integer
weight values from 1760 to 4840, and data on the fitted value
of the spline of the specified degree at the specified weight,
and also the values of the 6 reference splines of the basis for
the same degree at the same weight. Therefore, the user must
run dscreate1.do to produce the datasets input by figures1.do
and figures2.do.

The do-files require a set of packages, downloadable from SSC,
in order to work. The list of necessary packages for each
do-file is given in a comment at the top of the file. However,
the full list, for all the 4 do-files, is:

scheme_rbn1mono, bspline, descsave, keyby, parmest, expgen,
eclplot, varlabdef, lablist, regaxis, fvprevar, prodvars,
fvregen, factext

All of these can be downloaded from SSC using the ssc command,
although some require Stata Version 11 or higher in order to
work. However, a suite of installation do-files is available
to install all SSC packages written by Roger Newson. They can
be downloaded by typing, in Stata,

net describe instasisay, from(http://www.imperial.ac.uk/nhli/r.newson/docribs)

and getting the ancillary files. Alternatively, the user can
download them, using a browser, from Roger Newson's website at

http://www.imperial.ac.uk/nhli/r.newson/stata.htm

Roger B. Newson
16 March 2011
