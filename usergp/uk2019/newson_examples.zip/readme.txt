Example data file and do-files for this presentation

This file documents the other example files in this folder.
The datafile and do-files for this presentation are as follows:

File              Description
----              -----------
candidate1.dta    Dataset with 1 observation per anonymized candidate
blandaltman1.do   Do-file to do the Bland-Altman analysis
riditspline1.do   Do-file to do the ridit spline analysis

The file candidate1.dta is the input file used by the 2 do-files.
The dataset and the analyses are described in the presentation.

Roger Newson
10 September 2019
