Files in this folder

The files in this folder can be used to give a presentation given at
the 11th UK Stata User Meeting on 17-18 May 2005, with the title

"Generalized confidence interval plots using commands or dialogs"

which introduces the -eclplot- package, downloadable from SSC. This
presentation is given using an Adobe Acrobat overhead projection file,
which includes an introductory series of frames, followed by a series
of pages of notes describing a demonstration of -eclplot-. This
demonstration can be given using Version 8.2 of Stata, and should
probably work under higher versions. The user can extract the contents
of this folder into a new folder under his/her own system, and will
then be able to give the same demonstration, using Stata 8.2 in the new
folder.

The files belong to 2 subsets. The .pdf and .do files are special files
created for the presentation and the demonstration. The .ado, .dlg and
.hlp files are all parts of the unofficial Stata packages -eclplot-,
-parmest-, -sencode- and -somersd-, which are required for the
demonstration. The user can install the latest versions of these
packages from SSC within Stata, using the -ssc- command. The versions
in this folder are the current versions at the time of the 11th UK
Stata User Meeting on 17-18 May 2005. They are provided in this folder so
that users can demonstrate the packages under their own systems, before
deciding whether to install the packages from SSC.

The files in this folder (apart from this one) are as follows:

Filename                Description
--------                -----------
newson_ohp1.pdf         Overhead projection file for the presentation
example1.do             First example do-file for the demonstration
example2.do             Second example do-file for the demonstration
cendif.ado              Part of the -somersd- package
eclplot.ado             Part of the -eclplot- package
parmby.ado              Part of the -parmest- package
parmest.ado             Part of the -parmest- package
sencode.ado             Part of the -sencode- package
somers_p.ado            Part of the -somersd- package
somersd.ado             Part of the -somersd- package
eclplot.dlg             Part of the -eclplot- package
eclplot_98s.dlg         Part of the -eclplot- package
cendif.hlp              Part of the -somersd- package
eclplot.hlp             Part of the -eclplot- package
parmby.hlp              Part of the -parmest- package
parmest.hlp             Part of the -parmest- package
sencode.hlp             Part of the -sencode- package
somersd.hlp             Part of the -somersd- package

Roger Newson
5 May 2005
