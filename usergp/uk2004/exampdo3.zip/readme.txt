-------------------------------
Example do-files in this folder
-------------------------------

The example do-files in this folder are executed for demonstration as part of a
survey presentation "From datasets to resultssets in Stata", given at the 10th
UK Stata User Meeting on 29 June 2004. The example do-files are as follows:

Do-file          Description
-------          -----------
example1.do      Demonstration of descsave, parmby, xcollapse and xcontract
example2.do      Concatenating and merging resultssets in tempfiles
example3.do      Creating a plot and table using sencode and sdecode
example4.do      Confidence interval plots using factext and factmerg
example5.do      Improved version of example4.do creating Figure 1 and Table 1

They can be run by users with Stata 8 and the required packages (see below).
The versions in this folder do not produce any output files. However, they
contain comment lines of the form

* graph saving exampleX

which, if modified by removing the "* " at the beginning, will be command lines.
If executed, these command lines will produce Stata graph files, containing the
Figures in the handout, with names of the form "figureX.gph" for Figure X.
The Figures will then be produced by the do-files as follows:

Figure          Example do-file  Description of Figure
------          ---------------  ---------------------
figure1.gph     example5.do      Advanced multi-factor confidence interval plot
figure2.gph     example3.do      Basic Somers' D confidence interval plot
figure3.gph     example4.do      Basic single-factor confidence interval plot
figure4.gph     example4.do      Basic multi-factor confidence interval plot

Unofficial Stata packages required
----------------------------------

Each individual example do-file contains, near the top, a list of the packages
that it requires. However, the example do-files will all work under Stata 8 if
the user has installed all the following packages, downloadable from the SSC
site within Stata:

Package     Description
-------     -----------
descsave    Extension of describe creating output files
parmest     Convert estimation results to a data set with 1 obs per parameter
xcollapse   Make data set of summary statistics on disk or in memory
xcomtract   Make data set of frequencies and percents on disk or in memory
eclplot     Horizontal and vertical confidence interval plots
listtex     List observations as rows of a TeX, HTML or word processor table
dsconcat    Concatenate a list of Stata data files into the memory
sencode     Encode a string variable non-alphabetically to a numeric variable
sdecode     Decode a numeric variable to string, formatting unlabelled values
factext     Extract factor values from a label variable created by parmest
factmerg    Merge a list of factors to create string variables
ingap       Insert gap observations in a dataset
somersd     Estimate Kendall's tau-a, Somers' D and median differences

In web-aware Stata 8, a package named package_name can be described and
installed as follows. Type

ssc describe package_name

to describe the package. Then type

ssc install package_name

to install the package.

Roger Newson
17 June 2004
